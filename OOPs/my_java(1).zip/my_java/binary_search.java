import java.util.*;
class sort{
 public static void main(String args[]){
 	Scanner in = new Scanner(System.in);
 	int n;
 	System.out.println("enter no. of elements in an array: ");
 	n=in.nextInt();
 	int[] arr = new int[n];
 	System.out.println("enter array elements: " );
 	for(int i=0;i<n;i++){
 	arr[i]=in.nextInt();
 	}
 	System.out.println("given array: " );
 	for(int i=0;i<n;i++){
 	System.out.print(arr[i]+" ");
 	}

 	 for(int i=0;i<n;i++){
 	System.out.print(arr[i]+" ");
 	}
  	return;
 	}
}
    
