import java.util.*;

abstract class shape{
	
	shape(){ 
	 // System.out.println("abstract class constructor");
	}
	abstract void getArea();
	abstract void getVolume();
}
class square extends shape{
   int side=5;
   
   void getArea(){
     System.out.println(side*side);
     }
     void getVolume(){
     System.out.println("oops! square is 2-D shape, volume not possible..");
     }
     
}
class circle extends shape{
   double radius=5;
   
   void getArea(){
     System.out.println(3.14*radius*radius);
     }
     void getVolume(){
     System.out.println("oops! circle is 2-D shape, volume not possible..");
     }
     
}
class cube extends shape{
   int side=5;
   
   void getArea(){
     System.out.println(side*side*side);
     }
     void getVolume(){
     System.out.println(6*side*side);
     }
     
}
class sphere extends shape{
   double radius=5;
   
   void getArea(){
     System.out.println(4/3*3.14*radius*radius*radius);
     }
     void getVolume(){
     System.out.println(4*3.14*radius*radius);
     }
     
}
class Test1{
   public static void main(String args[]){
   	square sq= new square();
	sq.getArea();
   	sq.getVolume();
   	System.out.println();
   	circle cir= new circle();
	cir.getArea();
   	cir.getVolume();
   	System.out.println();
   	cube c= new cube();
	c.getArea();
   	c.getVolume();
   	System.out.println();
   	sphere s= new sphere();
	s.getArea();
   	s.getVolume();
   	return;
  }
 
} 
	
	




