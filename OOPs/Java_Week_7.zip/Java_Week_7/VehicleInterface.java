import java.util.*;

interface Vehicle
{	
	public String getColor();
	public int getNumbers();
	public double getConsumption();
	

}
class TwoWheeler implements Vehicle
{
	String name;
	String color;
	int number;
	double fuelcon;
	void setData(String name,String color,int number,double fuelcon)
	{
		this.name=name;
		this.color=color;
		this.number=number;
		this.fuelcon=fuelcon;
	}
	public String getName()
	{
		return name;
	}
	public String getColor()
	{
		return color;
	}
	public int getNumbers()
	{
		return number;
	}
	public double getConsumption()
	{
		return fuelcon;
	}
}
class FourWheeler implements Vehicle
{
	String name;
	String color;
	int number;
	double fuelcon;
	void setData(String name,String color,int number,double fuelcon)
	{
		this.name=name;
		this.color=color;
		this.number=number;
		this.fuelcon=fuelcon;
	}
	public String getName()
	{
		return name;
	}
	public String getColor()
	{
		return color;
	}
	public int getNumbers()
	{
		return number;
	}
	public double getConsumption()
	{
		return fuelcon;
	}

}
class VehicleInterface
{
	public static void main(String args[])
	{
	TwoWheeler two=new TwoWheeler();
	two.setData("Duke","Orange",1490,500.12);
	String name=two.getName();
	String color=two.getColor();
	int num=two.getNumbers();
	double cons=two.getConsumption();
	System.out.println("\n Name : "+name+"\n Color : "+color+"\n Number : "+num+"\n Consumption : "+cons);
	
	FourWheeler four=new FourWheeler();
	four.setData("Bus","Green",9900,80000);
	 name=four.getName();
	 color=four.getColor();
	 num=four.getNumbers();
	 cons=four.getConsumption();
	System.out.println("\n Name : "+name+"\n Color : "+color+"\n Number : "+num+"\n Consumption : "+cons);
	}
}
