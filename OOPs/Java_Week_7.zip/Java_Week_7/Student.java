import java.util.*;

interface StudentFee{

	public double getAmount();
	public String getFirstName();
	public String getLastName();
	public String getAddress();
	public String getContact();
}

class Hostler implements StudentFee{
	double amount;
	String fn, ln, add, con;
	Hostler(double amo, String fn, String ln, String add, String con){
	 this.amount= amo;
	 this.fn=fn;
	 this.ln=ln;
	 this.add=add;
	 this.con=con;
	 }
	 
	 public double getAmount(){
	  return amount;
	  }
	 public String getFirstName(){
	 return fn;
	 }
	 public String getLastName(){
	  return ln;
	  }
	  public String getAddress(){
	  return add;
	  }
	  public String getContact(){
	   return con;
	   } 
}

class Student{
  public static void main(String args[]){
  	StudentFee H=new Hostler(120000, "Ram", "Laxman", "Ayodhya", "9866970181");

  	System.out.println( H.getAmount()+ H.getFirstName()+ H.getLastName()+ H.getAddress()+H.getContact());
  return;
  
  }
  }
